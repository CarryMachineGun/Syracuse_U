package syr.edu.hw1;

// import syr.edu.hw1.Greeting;

class Hello{
    public static void main(String[] args){
        System.out.println("Hello World");

        Greeting g = new Greeting();
        g.greet();

        // Library l = new Library();
        // String books[] = new String[2];
        // books[0] = "awdawd";
        // books[1] = "awdwadawd"; 
        // l.init(books);
        // l.search();

        return;
    }
}