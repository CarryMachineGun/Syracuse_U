/*This line is to selet all the rows from a table*/
SELECT *
/*The selected table is 'Customers'*/
FROM Examples.dbo.Customers
/*The row be selected has a 'CustState = MA'*/
WHERE CustState = 'MA';