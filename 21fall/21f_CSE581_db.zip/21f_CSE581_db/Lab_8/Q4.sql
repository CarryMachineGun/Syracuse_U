USE ProductOrders
SELECT *
FROM sys.key_constraints
WHERE type = 'PK';