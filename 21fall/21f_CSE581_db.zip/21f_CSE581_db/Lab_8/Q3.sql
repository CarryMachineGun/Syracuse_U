--CREATE VIEW CustomerContact
--AS
--SELECT CustID, CustFirstName, CustLastName, CustPhone, CustFax
--FROM ProductOrders.dbo.Customers;

--UPDATE CustomerContact
--SET CustFax = 9999999999
--WHERE CustFax IS NULL;

SELECT * FROM CustomerContact