INSERT INTO TutoringCenter.dbo.Courses
VALUES 
(581, 'DB', 4000, '12:20', 5),
(623, 'DB', 4000, '12:20', 5),
(554, 'DB', 4000, '12:20', 5);