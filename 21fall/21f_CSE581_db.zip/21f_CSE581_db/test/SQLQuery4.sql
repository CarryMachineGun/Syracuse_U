SELECT *
FROM TutoringCenter.dbo.Courses;
