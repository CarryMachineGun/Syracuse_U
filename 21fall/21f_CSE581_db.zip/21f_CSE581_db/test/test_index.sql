USE TutoringCenter;

EXECUTE sp_helpindex StudyGroups;