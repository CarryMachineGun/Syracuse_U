USE MyGuitarShop;

SELECT * FROM Orders;