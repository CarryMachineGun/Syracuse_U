USE MyGuitarShop;

INSERT INTO Customers
	(EmailAddress, Password, FirstName, LastName)
VALUES
	('kriegerobert@gmail.com', '', 'Krieger', 'Robert');

SELECT * FROM Customers;