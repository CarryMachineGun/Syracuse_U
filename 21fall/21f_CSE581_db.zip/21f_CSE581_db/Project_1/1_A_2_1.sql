USE MyGuitarShop;

SELECT * FROM Customers;