-- select last name, first name and department number
select Employees.LastName, Employees.FirstName, Employees.DeptNo
-- from Employees table
from Examples.dbo.Employees;