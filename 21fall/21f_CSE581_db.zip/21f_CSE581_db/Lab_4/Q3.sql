SELECT *
FROM AP.dbo.VendorCopy
ORDER BY DefaultAccountNo;

--UPDATE AP.dbo.VendorCopy
--SET DefaultAccountNo = 431
--WHERE DefaultAccountNo = 170;