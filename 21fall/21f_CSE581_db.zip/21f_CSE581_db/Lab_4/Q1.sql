SELECT *
INTO AP.dbo.VendorCopy
FROM AP.dbo.Vendors;

SELECT *
INTO AP.dbo.InvoiceCopy
FROM AP.dbo.Invoices