SELECT *
FROM AP.dbo.InvoiceCopy;

--INSERT AP.dbo.InvoiceCopy
--VALUES (115, 'CM-004-400', 09/01/15, 400.30, 2.50, 4.99, 2, 09/01/15, NULL)