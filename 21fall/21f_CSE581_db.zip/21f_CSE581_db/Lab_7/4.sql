USE TutoringCenter;

ALTER TABLE Students
ADD CourseFeePaid bit NOT NULL DEFAULT 0;